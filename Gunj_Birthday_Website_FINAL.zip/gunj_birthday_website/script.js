// ==============================
// GUNJ'S BIRTHDAY WEBSITE
// Edit the text below if you want.
// ==============================

const BIRTHDAY = null;
// Example: "2026-10-15T00:00:00"
// Leave null to show 00:00:00 and let her open it immediately.

const slides = [
  {
    type:"letter",
    icon:"🎂",
    title:"Happy Birthday",
    text:"Gunj, 2000 years in the future, you’ll still be the person I’d choose first. You make ordinary days feel special, and somehow every memory with you becomes one I want to keep forever. Happy birthday, Chikini.",
    sig:"— Aryan"
  },
  {
    type:"letter",
    icon:"♡",
    title:"What I love most about you",
    text:"Your laugh. Your little expressions. The way you make everything more fun without even trying. But mostly, I love the person I get to be when I’m with you.",
    sig:"— Aryan"
  },
  {
    type:"letter",
    icon:"✦",
    title:"Our Story",
    text:"There are a million tiny moments that make up us. The random conversations, the stupid jokes, the photos, the quiet moments and the chaos. I wouldn't trade our story for anything.",
    sig:"— Aryan"
  },
  {
    type:"letter",
    icon:"☄",
    title:"Shared Dreams",
    text:"I want more ordinary days with you. More pictures, more laughing until it hurts, more adventures, more memories, and a future that still feels like us.",
    sig:"— Aryan"
  },
  {
    type:"memories",
    icon:"▣",
    title:"Our Memories"
  },
  {
    type:"song",
    icon:"♫",
    title:"Our Song"
  }
];

const giftScreen=document.getElementById("giftScreen");
const countdownScreen=document.getElementById("countdownScreen");
const letterScreen=document.getElementById("letterScreen");
const card=document.getElementById("letterCard");
const dots=document.getElementById("topDots");
const musicPlayer=document.getElementById("musicPlayer");
const audio=document.getElementById("audio");
const playPause=document.getElementById("playPause");
let current=0;
let timer=null;

function setupDots(){
  dots.innerHTML="";
  slides.forEach((_,i)=>{
    const d=document.createElement("span");
    d.className="dot"+(i===0?" active":"");
    d.onclick=()=>go(i);
    dots.appendChild(d);
  });
}
setupDots();

function render(){
  const s=slides[current];
  card.classList.add("fade");
  setTimeout(()=>{
    if(s.type==="memories"){
      card.innerHTML=`
        <div class="card-icon">${s.icon}</div>
        <h3>${s.title}</h3>
        <div class="memories-grid">
          <img src="images/photo3.jpg"><img src="images/photo4.jpg">
          <img src="images/photo5.jpg"><img src="images/photo6.jpg">
          <img src="images/photo1.jpg"><img src="images/photo7.jpg">
          <img src="images/photo8.jpg"><img src="images/photo2.jpg">
        </div>
        <div class="sig">Some moments that mean everything.</div>`;
    } else if(s.type==="song"){
      card.innerHTML=`
        <div class="card-icon">${s.icon}</div>
        <h3>${s.title}</h3>
        <div class="song-card">
          <img class="song-cover" src="images/photo3.jpg">
          <div class="song-meta"><strong>Until I Found You</strong><span>Stephen Sanchez</span></div>
          <span class="spotify-dot">◉</span>
        </div>
        <div class="sig">The song that belongs to us.</div>`;
    } else {
      card.innerHTML=`
        <div class="card-icon">${s.icon}</div>
        <h3>${s.title}</h3>
        <p>${s.text}</p>
        <div class="sig">${s.sig}</div>`;
    }
    card.classList.remove("fade");
  },170);

  document.querySelectorAll(".dot").forEach((d,i)=>d.classList.toggle("active",i===current));
  musicPlayer.classList.toggle("show",current===slides.length-1);
  if(current!==slides.length-1){ audio.pause(); playPause.textContent="▶"; }
}

function go(i){
  current=(i+slides.length)%slides.length;
  render();
}
document.getElementById("prev").onclick=()=>go(current-1);
document.getElementById("next").onclick=()=>go(current+1);

function makeFloatingPhotos(){
  const wrap=document.getElementById("floatingPhotos");
  wrap.innerHTML="";
  const data=[
    ["photo1.jpg","always us","a"],["photo5.jpg","my favorite","b"],
    ["photo2.jpg","our chaos","c"],["photo7.jpg","good times","d"]
  ];
  data.forEach(([src,label,cls])=>{
    const p=document.createElement("div");
    p.className=`photo-polaroid ${cls}`;
    p.innerHTML=`<img src="images/${src}"><span>${label}</span>`;
    wrap.appendChild(p);
  });
}

function confetti(){
  const wrap=document.getElementById("sparkles");
  wrap.innerHTML="";
  const colors=["#f06da5","#e7c56d","#9ec6d6","#c5a7d7","#f4f0e9"];
  for(let i=0;i<85;i++){
    const x=document.createElement("i");
    x.className="confetti-piece";
    x.style.left=Math.random()*100+"%";
    x.style.background=colors[i%colors.length];
    x.style.animationDelay=(-Math.random()*4)+"s";
    x.style.animationDuration=(3+Math.random()*4)+"s";
    wrap.appendChild(x);
  }
}

function showLetter(){
  countdownScreen.classList.remove("active");
  letterScreen.classList.add("active");
  makeFloatingPhotos();
  confetti();
  render();
}

document.getElementById("openGift").onclick=()=>{
  giftScreen.classList.add("opening");
  setTimeout(()=>{
    giftScreen.classList.remove("active");
    countdownScreen.classList.add("active");
    startCountdown();
  },700);
};

document.getElementById("enterLetter").onclick=showLetter;

function startCountdown(){
  if(!BIRTHDAY){
    ["days","hours","minutes","seconds"].forEach(id=>document.getElementById(id).textContent="00");
    return;
  }
  const target=new Date(BIRTHDAY).getTime();
  if(timer) clearInterval(timer);
  timer=setInterval(()=>{
    const diff=Math.max(0,target-Date.now());
    const s=Math.floor(diff/1000);
    document.getElementById("days").textContent=String(Math.floor(s/86400)).padStart(2,"0");
    document.getElementById("hours").textContent=String(Math.floor(s%86400/3600)).padStart(2,"0");
    document.getElementById("minutes").textContent=String(Math.floor(s%3600/60)).padStart(2,"0");
    document.getElementById("seconds").textContent=String(s%60).padStart(2,"0");
  },1000);
}

playPause.onclick=()=>{
  if(audio.paused){
    audio.play().then(()=>playPause.textContent="❚❚").catch(()=>{});
  }else{
    audio.pause();playPause.textContent="▶";
  }
};
audio.addEventListener("ended",()=>playPause.textContent="▶");

// Keyboard navigation
window.addEventListener("keydown",e=>{
  if(!letterScreen.classList.contains("active")) return;
  if(e.key==="ArrowRight") go(current+1);
  if(e.key==="ArrowLeft") go(current-1);
});
