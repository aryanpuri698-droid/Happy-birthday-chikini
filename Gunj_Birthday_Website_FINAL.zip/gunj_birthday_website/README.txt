GUNJ BIRTHDAY WEBSITE — READY TO PERSONALIZE

This project recreates the sequence from the reference video:
1. Dark gift box opening
2. Gunj/Gunjuuuu countdown intro
3. Birthday letter
4. What I love most about you
5. Our Story
6. Shared Dreams
7. Our Memories photo collage
8. Our Song with Until I Found You / Stephen Sanchez

YOUR PHOTOS
All 8 uploaded photos are already inside images/ as photo1.jpg ... photo8.jpg.

MUSIC
The audio used in the reference video was extracted and placed at:
images/until-i-found-you.mp3

If you own/have permission to use the song, it will play when she presses the play button. Browsers normally block autoplay, so the user must tap play.

COUNTDOWN
Open script.js and change:
const BIRTHDAY = null;

to something like:
const BIRTHDAY = "2026-10-15T00:00:00";

If you don't want a countdown, leave it null.

TEXT
All visible messages are in the `slides` array in script.js.
Change the text, but keep the quotes/backticks intact.

RUN LOCALLY
Open index.html in a modern browser.

PUT IT ONLINE
Use any static website host. Upload the whole folder, not only index.html.
Then send the generated website link to Gunj.

IMPORTANT
The exact song audio is included because it came from the user-provided reference video. If you publish the site publicly, make sure you have the right to use that recording.
